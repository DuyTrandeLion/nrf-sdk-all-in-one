#ifndef __LP55231_H__
#define __LP55231_H__

void lp55231_config(const nrf_drv_twi_t * m_twi);
void test_lp55231(const nrf_drv_twi_t * m_twi);

#endif //__LP55231_H__
